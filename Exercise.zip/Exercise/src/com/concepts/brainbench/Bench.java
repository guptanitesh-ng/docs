package com.concepts.brainbench;

public class Bench {

	public void printIt() {
		System.out.println("Bench");
	}
	
	public void printIt(boolean bool) {
		printIt();
	}
}
