package com.concepts.brainbench;

public class Brain extends Bench {

	public void printIt() {
		System.out.println("Brain");
	}
}
